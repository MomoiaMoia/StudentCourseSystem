package StudentCourseSystem;

import java.util.ArrayList;

public class TestMain {
    public static void main(String[] args) {
        // 使用 ArraryList studentList

        // 学生初始化
        ArrayList<Student> studentList = new ArrayList<Student>();
        Student momoia = new Student("Momoia");
        Student momori = new Student("momori");
        studentList.add(momoia);
        studentList.add(momori);

        // 教师初始化
        Teacher koko = new Teacher();

        // 课程初始化
        Course java = new Course("java");
        Course python = new Course("python");
        Course c = new Course("c++");

        System.out.println(" *　课程初始化");
        Course.initCou(new String[] { "r", "go" });
        Course.print();
        System.out.println("\n------------");

        // 学生选课测试
        System.out.println("------------为 Momoia 执行选课测试");
        momoia.select();
        System.out.println("------------执行选课结果展示");
        momoia.printSelect();
        System.out.println("------------");

        // 教师修改分数测试
        System.out.println("------------执行分数修改测试");
        koko.grade();
    }
}
