package StudentCourseSystem;

import java.util.HashMap;

public class Course {
    /**
     * @param cid     课程号 由 HashMap 的 Size 确定
     * @param cname   课程名 toString 返回该值
     * @param courses 课程列表 KEY 为 课程号， VALUE 为 课程对象
     */
    private int cid;
    private String cname;
    private static HashMap<Integer, Course> courses = new HashMap<Integer, Course>();

    public Course(String cname) {
        this.cid = courses.size() + 1;
        this.cname = cname;
        courses.put(this.cid, this);
    }

    public static HashMap<Integer, Course> getCourses() {
        return courses;
    }

    public int getCid() {
        return cid;
    }

    public String getCname() {
        return cname;
    }

    @Override
    public String toString() {
        return this.cname;
    }

    public static void initCou(String[] coursesNames) {
        for (String course : coursesNames) {
            Course _temp = new Course(course);
        }
    }

    public static void print() {
        for (Course course : courses.values()) {
            System.out.println(" - 课程号：" + course.getCid() + "\t" + "课程名："+ course.getCname());
        }
    }

}
